package com.example.demo.model;

public enum Role {
    ADMIN,
    USER,
    TEACHER,
    STUDENT
}
